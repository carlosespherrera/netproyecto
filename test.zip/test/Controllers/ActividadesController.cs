using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore; 
using test.Models;

public class ActividadesController : Controller
{
    private readonly ApplicationDbContext _context; 

    public ActividadesController(ApplicationDbContext context)
    {
        _context = context;
    }

    public IActionResult Index()
    {
        var actividades = _context.Actividades.ToList();

        return View(actividades); 
    }

    [HttpPost]
    public IActionResult AgregarActividad(Actividad actividad)
    {
        if (ModelState.IsValid)
        {
            _context.Actividades.Add(actividad); 
            _context.SaveChanges();

            return RedirectToAction("Index"); 
        }

        return View(actividad); 
    }
}
